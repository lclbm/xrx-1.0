from pathlib import Path

print(Path("/path/to/file"))