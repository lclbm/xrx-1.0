何志武223 = {
    'membershipid': '4611686018497181967',
    'membershiptype_num': 3,
    'membershiptype_char': 'steam',
    '宇宙回旋I': 7,
    '信仰屠戮I':7
    
}

信仰屠戮I = 4114145492
宇宙回旋I = 4130923084


王老头儿 = {
    'membershipid': '4611686018491540742',
    'membershiptype_num': 3,
    'membershiptype_char': 'steam',
    '宇宙回旋I': 6,
    '信仰屠戮I':7
}
