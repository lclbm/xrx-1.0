import nonebot
from nonebot import on_request, RequestSession
from nonebot.permission import SUPERUSER, PRIVATE_FRIEND, check_permission
import asyncio
from . import *


@on_request('friend')
async def friend_req(session):
    ev = session.event
    await session.bot.set_friend_add_request(flag=ev.flag,
                                            approve=True)


@on_request('group')
async def group_invite(session):
    ev = session.event
    await session.bot.set_group_add_request(flag=ev.flag,
                                            sub_type=ev.sub_type,
                                            approve=True)